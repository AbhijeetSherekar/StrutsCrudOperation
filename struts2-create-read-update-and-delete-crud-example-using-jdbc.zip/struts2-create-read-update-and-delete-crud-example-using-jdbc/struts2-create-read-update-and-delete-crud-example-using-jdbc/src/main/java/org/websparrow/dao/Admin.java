package org.websparrow.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin {
	
	// method for create connection
	public static Connection getConnection() throws Exception {
		try {
		
		Class.forName("org.postgresql.Driver");
	    return  DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres");

		} catch (SQLException e) {
	        throw new RuntimeException("Cannot connect to database", e);
	    }
	}
	

	// method for save user data in database
	public int registerUser(String ename, String email, String eaddress, String edeg,String gender,String skills,String birthday, String state, String city) throws Exception {
		int i = 0;
		try {
			String sql = "INSERT INTO EMPLOYEE VALUES (?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, ename);
			ps.setString(2, email);
			ps.setString(3, eaddress);
			ps.setString(4, edeg);
			ps.setString(5, gender);
			ps.setString(6, skills);
			ps.setString(7, birthday);
			ps.setString(8, state);
			ps.setString(9, city);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return i;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for fetch saved user data
	public ResultSet report() throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT ENAME,EMAIL,EADDRESS,EDEG,GENDER,SKILLS,BIRTHDAY,STATE,CITY FROM EMPLOYEE";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for fetch old data to be update
	public ResultSet fetchUserDetails(String email) throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT ename,email,eaddress,edeg,gender,skills,birthday,state,city FROM employee  WHERE email=?;";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, email);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}
	
	
	
	// method for update new data in database
	public int updateUserDetails(String ename, String email, String eaddress, String edeg, String gender,String skills,String birthday , String state, String city,  String uemailhidden)
			throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;
		try {
			String sql = "UPDATE EMPLOYEE SET ENAME=?,EMAIL=?,EADDRESS=?,EDEG=?,GENDER=?,SKILLS=?,BIRTHDAY=?,STATE=?,CITY=? WHERE EMAIL=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, ename);
			ps.setString(2, email);
			ps.setString(3, eaddress);
			ps.setString(4, edeg);
			ps.setString(5, gender);
			ps.setString(6, skills);
			ps.setString(7, birthday);
			ps.setString(8, state);
			ps.setString(9, city);
			ps.setString(10, uemailhidden);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for delete the record
	public int deleteUserDetails(String ename) throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;
		try {
			String sql = "DELETE FROM EMPLOYEE WHERE EMAIL=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, ename);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}
}
